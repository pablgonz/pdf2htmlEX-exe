Technical References
====================

..
   These are sorted by their titles.
   This would be nice: https://github.com/sphinx-doc/sphinx/issues/1430

.. toctree::
   techref/gposgsub
   techref/AA-Comparison
   techref/autotrace
   techref/accented
   techref/bezier
   techref/askmulti
   techref/ref-caveats
   techref/sfdchangelog
   techref/cidmapformat
   techref/cliargs
   techref/splinefont
   techref/SuggestDeltas
   techref/stroke
   techref/pyextend
   techref/BDFGrey
   techref/PfaEdit-TeX
   techref/pfaeditmath
   techref/hinting
   techref/macformats
   techref/featurefile
   techref/non-standard
   techref/palmfonts
   techref/plugins
   techref/bitmaponlysfnt
   techref/sfdformat
   techref/pcf-format
   techref/TrueOpenTables
   techref/corpchar
   techref/UniqueID
   techref/selections
