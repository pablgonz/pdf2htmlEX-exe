Tutorial
========

.. toctree::
   :numbered:
   :maxdepth: 2

   tutorial/editexample
   tutorial/editspiro
   tutorial/importexample
   tutorial/editexample2
   tutorial/editexample3
   tutorial/editexample4
   tutorial/editexample5
   tutorial/editexample6
   tutorial/editexample6-5
   tutorial/editexample7
   tutorial/editexample8
   tutorial/scripting-tutorial
   tutorial/scriptnotes

Tutorial in other languages
---------------------------

`Tutorial in Japanese <old/ja/editexample.html>`__
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

`Tutorial in German <old/de/editexample.html>`__
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^