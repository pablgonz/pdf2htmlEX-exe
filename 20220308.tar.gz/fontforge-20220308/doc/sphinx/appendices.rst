Appendices
==========

.. toctree::
   appendices/ff-history
   appendices/diffs
   appendices/files
   appendices/errrecovery
   appendices/nonbmp
   appendices/quotations
   appendices/uitranslationnotes
   appendices/fontstyles
   appendices/OFL-Unofficial
   appendices/bibliography

`Japanese documentation (outdated) <old/ja>`__
----------------------------------------------

* `Overview <old/ja/overview.html>`__