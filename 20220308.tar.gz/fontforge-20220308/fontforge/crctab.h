#ifndef FONTFORGE_CRCTAB_H
#define FONTFORGE_CRCTAB_H

extern unsigned long binhex_crc(unsigned char *buffer, int size);

#endif /* FONTFORGE_CRCTAB_H */
