#ifndef FONTFORGE_CLIPNOUI_H
#define FONTFORGE_CLIPNOUI_H

#include "uiinterface.h"

extern void FF_SetClipInterface(struct clip_interface *clipi);

#endif /* FONTFORGE_CLIPNOUI_H */
