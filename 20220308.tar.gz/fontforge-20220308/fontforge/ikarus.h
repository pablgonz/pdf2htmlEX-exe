#ifndef FONTFORGE_IKARUS_H
#define FONTFORGE_IKARUS_H

#include "splinefont.h"

extern SplineFont *SFReadIkarus(char *fontname);

#endif /* FONTFORGE_IKARUS_H */
